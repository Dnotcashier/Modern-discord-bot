const mySecret = process.env['TOKEN'];
const { Client } = require('discord.js');
const client = new Client();
const { token } = require('./config/bot.json');
const { keep_alive } = require('./keep_alive');

require('./utils/defines')(client);
require('./utils/structure/registery')(client);
require('./utils/handlers/commands')(client);
require('./utils/handlers/events')(client);

client.on('message', async message => {
	message.channel.messages.fetch();
	require('./utils/handlers/handler')(client, message);
});

client.on('messageUpdate', (o, message) => {
	require('./utils/handlers/editHandles')(client, message);
});

client.login(process.env.TOKEN);
client.on('message', async message => {
	if (message.content.startsWith('Hi')) {
		message.channel.send(`sup`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Hru')) {
		message.channel.send(`im fine, you?`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Good')) {
		message.channel.send(`Mkay`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Lmao')) {
		message.channel.send(`Huh? whats funny?`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Bruh')) {
		message.channel.send(`BIG BRUH MOMENTO`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Im sad')) {
		message.channel.send(`WHY?! UR SUCH AN AMAZING PERSON!`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Tag')) {
		message.channel.send(`##`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Nothing')) {
		message.channel.send(`Ur sus!`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Reddit')) {
		message.channel.send(` I am a bot, and this action was performed automatically. Please contact the moderators of this subreddit if you have any questions or concerns.`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('whats your name?')) {
		message.channel.send(`whats my name? i am toolbox`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('invite')) {
		message.channel.send(
			`wanna invite me ? here's the link
https://discord.com/api/oauth2/authorize?client_id=885370454385238056&permissions=8&scope=bot`
		);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('haha')) {
		message.channel.send(`Lol!`);
	}
});
client.on('message', async message => {
	if (message.content.startsWith('Your a wizard harry')) {
		message.channel.send(` I am a what?`);
	}
});